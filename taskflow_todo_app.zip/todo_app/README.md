# TaskFlow — Flask To-Do App

A clean, full-featured to-do app built with Flask and Bootstrap 5.

## Features
- ✅ Add, edit, delete tasks
- ✅ Toggle tasks done/undone
- ✅ Priority levels (High / Medium / Low)
- ✅ Filter by All / Active / Done
- ✅ Clear all completed tasks
- ✅ Bootstrap 5 responsive UI

## Project Structure
```
todo_app/
├── app.py                  # Flask routes & logic
├── requirements.txt
├── templates/
│   ├── base.html           # Shared navbar + layout
│   ├── index.html          # Task list + add form
│   └── edit.html           # Edit task form
└── static/
    └── css/
        └── style.css       # Custom styles
```

## Run Locally

```bash
# 1. Clone / download the project
cd todo_app

# 2. Create a virtual environment
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run the app
python app.py
```

Open http://127.0.0.1:5000 in your browser.

---

## Deploy to Render (free)

1. Push the project to a GitHub repository.
2. Go to https://render.com → **New → Web Service**.
3. Connect your GitHub repo.
4. Set:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `gunicorn app:app`
5. Add `gunicorn` to `requirements.txt`:
   ```
   flask>=3.0.0
   gunicorn
   ```
6. Click **Deploy**.

---

## Deploy to PythonAnywhere (free)

1. Sign up at https://www.pythonanywhere.com
2. Open a **Bash console** and run:
   ```bash
   git clone <your-repo-url>
   cd todo_app
   pip install --user -r requirements.txt
   ```
3. Go to **Web → Add a new web app → Flask**.
4. Set the source directory and WSGI file to point at `app.py`.
5. Reload the app.

---

## Upgrade: Use SQLite for Persistence

Replace the in-memory `todos` list with SQLite using `flask-sqlalchemy`:

```python
pip install flask-sqlalchemy
```

Then define a `Todo` model and swap out the list operations with DB queries.
