from flask import Flask, render_template, request, redirect, url_for
from datetime import datetime

app = Flask(__name__)

# In-memory store (replace with SQLite/DB for production)
todos = []
next_id = 1

def get_todo(todo_id):
    return next((t for t in todos if t["id"] == todo_id), None)

@app.route("/")
def index():
    filter_by = request.args.get("filter", "all")
    if filter_by == "active":
        filtered = [t for t in todos if not t["done"]]
    elif filter_by == "done":
        filtered = [t for t in todos if t["done"]]
    else:
        filtered = todos
    counts = {
        "all": len(todos),
        "active": sum(1 for t in todos if not t["done"]),
        "done": sum(1 for t in todos if t["done"]),
    }
    return render_template("index.html", todos=filtered, filter=filter_by, counts=counts)

@app.route("/add", methods=["POST"])
def add():
    global next_id
    text = request.form.get("text", "").strip()
    priority = request.form.get("priority", "medium")
    if text:
        todos.append({
            "id": next_id,
            "text": text,
            "done": False,
            "priority": priority,
            "created_at": datetime.now().strftime("%b %d, %Y")
        })
        next_id += 1
    return redirect(url_for("index"))

@app.route("/toggle/<int:todo_id>")
def toggle(todo_id):
    todo = get_todo(todo_id)
    if todo:
        todo["done"] = not todo["done"]
    return redirect(request.referrer or url_for("index"))

@app.route("/delete/<int:todo_id>")
def delete(todo_id):
    global todos
    todos = [t for t in todos if t["id"] != todo_id]
    return redirect(request.referrer or url_for("index"))

@app.route("/edit/<int:todo_id>", methods=["GET", "POST"])
def edit(todo_id):
    todo = get_todo(todo_id)
    if not todo:
        return redirect(url_for("index"))
    if request.method == "POST":
        text = request.form.get("text", "").strip()
        priority = request.form.get("priority", "medium")
        if text:
            todo["text"] = text
            todo["priority"] = priority
        return redirect(url_for("index"))
    return render_template("edit.html", todo=todo)

@app.route("/clear-done")
def clear_done():
    global todos
    todos = [t for t in todos if not t["done"]]
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=True)
